package com.maisapires.todosimple.models.projection;

public interface TaskProjection {

    public Long getId();

    public String getDescription();

}