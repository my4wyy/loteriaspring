package com.maisapires.todosimple.models.dto;

public class ProductDeleteDTO {
    public Long id;
}
